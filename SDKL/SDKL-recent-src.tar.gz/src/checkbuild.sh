sudo rm /usr/bin/sdkl
sudo rm /usr/bin/sdkl-bytes

sudo ln ./sdkl /usr/bin/sdkl -s
sudo ln ./sdkl-bytes /usr/bin/sdkl-bytes -s

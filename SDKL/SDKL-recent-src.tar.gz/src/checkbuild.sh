PATH="$PATH:./"
export PATH

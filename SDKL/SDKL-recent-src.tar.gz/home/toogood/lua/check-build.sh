sudo rm /usr/bin/sdkl && sudo ln ./sdkl /usr/bin/sdkl


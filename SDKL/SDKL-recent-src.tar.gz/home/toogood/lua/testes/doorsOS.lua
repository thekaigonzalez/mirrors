-- doors.print("hello, DoorsOS!");

os.print("hello, DoorsOS!\n");
